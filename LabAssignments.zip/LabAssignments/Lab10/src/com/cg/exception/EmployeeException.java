package com.cg.exception;

public class EmployeeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeException(String msg){
    	super(msg);
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
