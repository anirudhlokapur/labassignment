package com.cg.lab9;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDate {

	@Test
public void testGetDay(){
		System.out.println("From TestDate Day ");
		Date date = new Date(11,11,1996);
		assertEquals(11, date.getDay());
	}	
@Test
public void testGetMonth(){
	System.out.println("From TestDate Month");
	Date date = new Date(11,11,1996);
	assertEquals(11, date.getMonth());
	
}
@Test
public void testGetYear(){
	System.out.println("From TestDate Year");
	Date date= new Date(11,11,1996);
	assertEquals(1996, date.getYear());
}
	
@Test
public void testSetDay(){
	System.out.println("From TestDate setDay");
	Date date= new Date(12,12,1212);
	date.setDay(8);
	assertTrue(date.getDay()== 8);
	
}
@Test
	public void testSetMonth(){
		System.out.println("From TestDate setMonth");
		Date date= new Date(12,12,1212);
		date.setMonth(5);
		assertTrue(date.getMonth() == 5);
}
		
@Test
public void testSetYear(){
	System.out.println("From TestDate setYear");
	Date date= new Date(12,12,1212);
	date.setYear(2012);
	assertTrue(date.getYear() == 2012);
}

	}


