package com.cg.lab9;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.Test;

public class TestPersonDetails {

	@Test
	public void testGetFirstName(){
		System.out.println("From TestPersonDetails getF_name");
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		assertEquals("Anirudh", person.getF_name());
	}
	
	@Test
	public void testGetLastName(){
		System.out.println("From TestPersonDetails getL_name");
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		assertEquals("Lokapur", person.getL_name());
	}
	
	@Test
	public void testGetGender(){
		System.out.println("From TestPersonDetails getGen");
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		assertEquals('M', person.getGen());
	}
	
	@Test
	public void testGetAge(){
		System.out.println("From TestPersonDetails getAge");
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		assertEquals(22, person.getAge());
	}
	
	@Test
	public void testGetWeight(){
		System.out.println("From TestPersonDetails getWeight");
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		assertEquals(63.5, person.getWht(),0.001);
		
	}

	@Test
	public void testGetPhoneNo(){
		System.out.println("From TestPersonDetails getPhoneNo");
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		assertEquals("8722429900", person.getPhno());
		
	}
	@Test 
	public void testSetFirstName(){
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		person.setF_name("Anirudh");
		assertTrue(person.getF_name() == "Anirudh");
	}
	
	@Test 
	public void testSetLastName(){
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		person.setL_name("Lokapur");
		assertTrue(person.getL_name() == "Lokapur");
	}
	
	@Test 
	public void testSetAge(){
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		person.setAge(22);
		assertTrue(person.getAge() == 22);
	}
	
	@Test 
	public void testSetWeight(){
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
		person.setWht(22);
		assertTrue(person.getWht() == 22);
	}
	
	@Test 
	public void testSetPhno(){
		PersonDetails person = new PersonDetails("Anirudh", "Lokapur", 'M', 22,63.5, "8722429900");
	String phno ="8722429900"; 
	InputStream in = new ByteArrayInputStream(phno.getBytes());
	 System.setIn(in);
		assertEquals("8722429900", person.setPhno());
		
	}
}
