package com.cg.lab4;

public class CurrentAccount extends Account {
	private double overdraftlimit;

	public CurrentAccount(long accnum, double balance, double overdraftlimit) {
		super(accnum, balance);
		this.overdraftlimit = overdraftlimit;
	
	}
	@Override
	public boolean withDraw(double amt){
		boolean res= amt>= overdraftlimit;
		return res;
	}

}
