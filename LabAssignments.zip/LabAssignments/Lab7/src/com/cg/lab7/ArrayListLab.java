package com.cg.lab7;

import java.util.ArrayList;

import java.util.Collections;
import java.util.Scanner;

public class ArrayListLab {
	
	private static Scanner sc;

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		System.out.println("Enter number of values to be inserted in Array List");
		sc = new Scanner(System.in);
		int n = sc.nextInt();
		for(int i=0;i<n;i++)
		{
			String str = sc.next();
			list.add(str);
		}
		Collections.sort(list);
		for (String s : list) {
			System.out.println(s+"\n");
			
		}
		
	}

}
