package com.cg.lab8_1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Lab8_1 {

	public static void main(String[] args) {
		
 try {
   
	FileInputStream fis = new FileInputStream("reverseString.txt");
	DataInputStream dis = new DataInputStream(fis);
	String str = dis.readLine();
	System.out.println(str);
	StringBuilder sb = new StringBuilder(str);
		sb.reverse();
	 FileOutputStream fos = new FileOutputStream("reverseString.txt");
		DataOutputStream dos = new DataOutputStream(fos);
		dos.writeUTF(sb.toString());
	System.out.println(sb.toString());
	dis.close();
	dos.close();
} catch (Exception e) {
	e.printStackTrace();
}
	}

}

